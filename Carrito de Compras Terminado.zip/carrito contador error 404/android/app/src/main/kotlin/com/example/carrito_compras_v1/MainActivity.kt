package com.example.carrito_compras_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
